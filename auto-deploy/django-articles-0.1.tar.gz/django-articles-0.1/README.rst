=====
Polls
=====

Articles is a simple Django app that display news articles from a json file. 

Quick start
-----------

1. Add "articles" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'articles',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('articles/', include('articles.urls')),

3. Run `python manage.py migrate` to create the articles models.

5. Visit http://127.0.0.1:8000/articles/ to view the page.