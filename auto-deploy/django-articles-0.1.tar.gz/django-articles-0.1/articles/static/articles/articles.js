function showCommentForm () {
    $("#comments-form").show();
    $("#enter-comment-btn").hide();
}